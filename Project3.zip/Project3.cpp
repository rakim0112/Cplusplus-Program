#include <iostream>
#include <fstream>
#include <map>
#include <string>
#include <iomanip>

using namespace std;

class GroceryTracker {
private:
    map<string, int> itemFrequency;

public:
    // Load the items from the input file and count frequencies
    void loadItemsFromFile(const string& filename) {
        ifstream inputFile(filename);
        string item;

        if (inputFile.is_open()) {
            while (getline(inputFile, item)) {
                itemFrequency[item]++;
            }
            inputFile.close();
        }
        else {
            cerr << "Unable to open file." << endl;
        }
    }

    // Option 1: Look for a specific item and return its frequency
    void findItemFrequency(const string& item) {
        if (itemFrequency.find(item) != itemFrequency.end()) {
            cout << item << " appears " << itemFrequency[item] << " times." << endl;
        }
        else {
            cout << item << " was not found." << endl;
        }
    }

    // Option 2: Print the list of items and their frequencies
    void printItemList() {
        for (const auto& entry : itemFrequency) {
            cout << entry.first << " " << entry.second << endl;
        }
    }

    // Option 3: Print the frequency of items as a histogram
    void printHistogram() {
        for (const auto& entry : itemFrequency) {
            cout << setw(15) << left << entry.first << " ";
            for (int i = 0; i < entry.second; i++) {
                cout << "*";
            }
            cout << endl;
        }
    }

    // Option 4: Save data to a backup file
    void saveDataToFile(const string& filename) {
        ofstream outputFile(filename);
        if (outputFile.is_open()) {
            for (const auto& entry : itemFrequency) {
                outputFile << entry.first << " " << entry.second << endl;
            }
            outputFile.close();
        }
        else {
            cerr << "Unable to open output file." << endl;
        }
    }
};

int main() {
    GroceryTracker tracker;
    string filename = "CS210_Project_Three_Input_File.txt";

    // Load items from the file
    tracker.loadItemsFromFile(filename);

    int choice;
    string item;

    do {
        cout << "\nMenu:\n";
        cout << "1. Find Frequency of a Specific Item\n";
        cout << "2. Print Item List and Frequencies\n";
        cout << "3. Print Histogram of Item Frequencies\n";
        cout << "4. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;
        cin.ignore();  // To ignore any newline character left in the buffer

        switch (choice) {
        case 1:
            cout << "Enter the item to search for: ";
            getline(cin, item);
            tracker.findItemFrequency(item);
            break;
        case 2:
            tracker.printItemList();
            break;
        case 3:
            tracker.printHistogram();
            break;
        case 4:
            tracker.saveDataToFile("frequency.dat");
            cout << "Data saved to frequency.dat." << endl;
            break;
        default:
            cout << "Invalid option, please try again." << endl;
        }

    } while (choice != 4);

    return 0;
}